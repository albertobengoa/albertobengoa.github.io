
## 1999-2005: B. S. in Computer Science, summa cum laude
#### University of A Coruña (Spain)

Dissertation (2005): "Decision support system for investment in telecommunication and mobile telephony networks under demand uncertainty."

[Dissertation PDF Link (Spanish)](resources/pdf/abengoa-dissertation-20050601.pdf)

[Presentation PDF Link (Spanish)](resources/pdf/abengoa-presentation-20050601.pdf)

___
