
## 2014-present: Senior Product Manager, Strategic Technical Office (STO)

### 1. Product Management

#### 1.a Product manager/project manager for data virtualization products


I am responsible for three of Denodo's data virtualization products, managing them during their conceptualization, design, implementation and operation.



<details>
  <summary>Denodo Community and Denodo Express (click for more details)</summary>

[Link to the Denodo Community](http://community.denodo.com)

[Link to Denodo Express](http://www.denodo.com/en/denodo-platform/denodo-express)

I was put in charge of both products when the Strategic Technical Office was tasked with making them a reality; the main challenges were to slowly align the expectations of all the departments with Denodo's strategic vision, and tackle the complexity of the products due to the sheer number of people involved in them - cross-company projects that needed to satisfy the (often conflicting) needs of Sales, Marketing, Product development, Operations and Services Engineering.

Both projects were released on September 2015, on time and with all launch goals achieved. The community has been steadily growing since its inception, getting high praise from customers due to the high quality of technical content and the helpfulness of other customers and Denodo staff in the Q&A section. It has also gathered excellent reviews by industry analysts (Forrester, Gartner, etc.) due to both the breadth and depth of the content that is offered for free, and also from the internal Sales and Sales Engineering teams as it has fulfilled the original goals of helping shorten the sales cycles (from the previous years' multi-year process to sales done under a quarter), quickly becoming strategic assets critical for Denodo's business model.

The driver of these products was a new strategic initiative to go from the traditional closed sales model (with prospective customers getting access to Denodo's technology and documentation only after signing NDAs) to an open model in which the company was to give free access to both software and resources to anyone. This intended to 1) raise awareness about data virtualization, by letting users to download the software for free and use them for self-training, POCs and small production usage, 2) shorten Denodo's sales cycles by letting leads to pre-qualify by researching and doing POCs on their own, and 3) increase brand value in enterprise and analysts circles.


</details>



<details>
  <summary>Denodo Platform for AWS (click for more details) </summary>

[Link to the Denodo Platform for AWS](http://www.denodo.com/en/denodo-platform/denodo-platform-for-aws)

I led the team in charge of this project in 2016, being successfully completed on April 2016; it is in launched and in production at [Amazon's AWS Marketplace](https://aws.amazon.com/marketplace/seller-profile/ref=srh_res_product_vendor?ie=UTF8&id=375933c7-ef48-4e99-a007-cb30e7bdf8d6). This was another multi-departmental project that required coordinating many people with different needs and defining the features of a completely new product in a new market for the company - while also interacting with an external third party (Amazon).

The Denodo Platform for AWS was born as a low-cost option that fills the gap between the Denodo Platform's free and enterprise versions. It allows customers to use the fully-featured version of the software with a pay-as-you-go model, adjusting to a big range of budgets; it also allows customers to deploy data virtualization on the cloud with minimal effort, as the Denodo Platform is available on the AWS Marketplace, and it allows Denodo's Sales organization to spend the bulk of their effort in important enterprise accounts by redirecting low-volume accounts to the light touch sales model of the Denodo Platform for AWS.

</details>

#### 1.b Product manager for enterprise ecosystem products

These are products that fill gaps in the core data virtualization platform and complete the feature set that an enterprise-class software product needs for good market adoption. I have been involved in conceptualizing, architecting, designing and prototyping these projects.


<details>
  <summary>Denodo Testing Tool</summary>

Since its first release, it has become an integral part of Denodo's customers' enterprise deployments and it is currently the highest-downloaded add-on to the core platform. I analyzed the business problem independently, drafted the requirements and designed the tool's interface. After the prototyping phase, I worked with the team at Denodo Labs for the final implementation.
The creation of this tool demonstrated excellent timing ahead of customer issues: two of Denodo's strategic customers requested this kind of tool after the design was already underway, so we could provide an immediate response and avoid possible negative repercussions. It is the first tool of its class in the market, scoring another win over Denodo's competitors.

The Denodo Testing Tool provides automated testing for the Denodo Platform; it allows to do unit testing on the command line over data services published through data virtualization, ensuring a high quality of deliverables and allowing to do regression testing in subsequent releases of the software and the underlying data virtualization platform.

</details>


<details>

  <summary>Denodo Diagnostics and Monitoring tool</summary>

Another tool that I independently conceptualized, researched, scoped and designed as part as my duties in the Strategic Technical Office. The tool proposal was accepted by the Product department and was successfully developed, being included in the core tool on April 2016.

Both the internal (Denodo's) and external (the customers') support and admin teams always faced problems when trying to diagnose issues with the software, due to a myriad of different log files spread across different locations, with different formats, that made very difficult to correlate the temporal information to understand the context of the failure, in addition to being difficult to visualize, filter, sort, etc.
The new diagnostics tool presents an integrated view of all the logs generated by the Denodo Platform, cutting the time needed by the customers' and Denodo's support teams to diagnose any issue, thus reducing the workload of an already strained team.


</details>

<details>

  <summary>Denodo Enterprise Manager</summary>

I analyzed the need for this tool, gathered the requirements, designed and prototyped it. The Enterprise Manager was conceptualized based on multiple instances of customer feedback, resulting in a client-server centralized manager for deployments that allows to manage every aspect of the configuration of multi-server installs, which is a critical process of any big software deployment.

I presented it internally to Denodo Labs and the Professional Services and Product Development departments - it was accepted for development and it is currently planned for release in the fall of 2016.

We predict that it will be an enormous differentiator against the competition when operative, because the Denodo Platform does not currently provide any feature to help manage the deployment configuration of the software. That is one of the critical tasks for enterprise customers that have big deployments (10+ servers) is to manage all the deployed instances in all environments (development, testing, pre-production, production, etc.) taking into account clustering configuration, matching platform versions, update scheduling, licensing configuration, etc.

</details>

<details>

  <summary>Denodo Model Bridge Tool</summary>

I was in charge of the design and prototyping from scratch the new tool, going through two prototypes that were presented to customers through the outreach program, to a beta that was again validated with customers, to finally being published and successfully used by Denodo's customers.

Enterprise modeling tools (ER/Studio, ERwin, PowerDesigner, etc.) are one of the most common ways Denodo's customers have to interact with their relational data sources. One piece of recurring feedback was to allow those data models to be used with the data virtualization tool, something not possible at the time, which sparked the creation of this model bridge tool.


</details>

### 2. Technical Writing

I am also author of in-depth technical cookbooks:

  - [Data Warehouse Off-loading (published)](http://www.denodo.com/en/document/e-book/cookbook-62-page-special-report-managing-data-warehouse-offloading-big-data),

  - Query optimization (work in progress).

These are in-depth manuals that contain detailed instructions for both architects and developers, and that contain cross-area instructions that would usually found scattered across different parts of the product/services documentation.
The main goals are:

  - Solve architect-level and developer-level concerns about use of the product and integration with third-party software in real-world deployments.

  - Increase visibility in the market and raise the quality of the Denodo brand by publishing high-value technical content.

Also authored several posts in [Denodo's corporate blog](http://www.datavirtualizationblog.com/).

### 3. Technical Partnerships

Responsible for technical interaction with partners: OEMs, technical certifications, VARs. For example:

  - Technical point of contact for the joint [Denodo+IBM partnership](http://www.denodo.com/en/document/solution-brief/achieve-value-and-insight-ibm-big-data-analytics-and-denodo-data)

  - Technical point of contact for the [Tableau-Denodo certification](http://www.denodo.com/en/partner/tableau), which included coding the first prototype of the integration software.

  - Technical point of contact for the Hadoop (both [Cloudera](http://www.denodo.com/en/partner/cloudera) and [Hortonworks](http://www.denodo.com/en/partner/hortonworks)) certifications.

  - Technical point of contact for the Snowflake certification (ongoing).

### 4. Customer Outreach Program

Involved in the definition and execution of the Denodo Strategic Customer Center initiative, with the goals of:

  - Centralizing the communication channels for existing customers with monthly webinars.

  - Maintaining the community up to date about the product's roadmap.

  - Presenting new and planned features to gather customer feedback, including producing beta and alpha versions and running early version programs with the customers.

### 5. Prospective Customer Training

Responsible for designing and teaching both low-level technical classes and architecture-level courses. More specifically, currently running [Denodo's monthly dv architect course](http://www.denodo.com/en/services/education/course/den60edua01/data-virtualization-architect).

The main goal of the data virtualization architect course has been to accelerate sales cycles by helping prospects to know the technology better, understand the full feature set and how it can be a critical piece of the solution for their data-related problems.

The course has received high praise from both the Sales organization and all prospects that have received it; it has been very successful as a piece of the sales acceleration plan, and the number of attendees has been growing from the beginning. In 2015 alone we trained over 150 architects, and the number for 2016 is already past 100.


### 6. Other Activities

Supporting the Marketing department by providing all technical information needed for the creation of their deliverables, including whitepapers, data sheets, web site content, webinars and on-premise lectures.

Supporting the Sales department in technical account management engagements:

  - Occasionally assist the Sales organization as a technical account manager when so required.

  - High success rate in closing the sale for several 6-figure accounts.

Supporting the Professional Services department in architectural engagements, doing on-site work to:

  - Help recent customers take the right first steps using data virtualization.

  - Review already started projects and steer them towards success.

  - Apply corrective measures to projects in danger of failure.

  - Technology- and business-level presentations, both creating the materials and delivering the presentations. Recent examples:

    - Lecture at the Data Virtualization Day at Eli Lilly, presenting the concept of data virtualization, what it means for a pharma company of the size of Eli Lilly, paired with a live coding exercise demonstrating the applicability of the tools to real world use cases.

    - Presentation to the CIO of a global insurance company about the high level implementation plan for data virtualization, including technology deployment steps, corporate communication plan, team readiness exercises, and project selection, categorization and execution.




## 2011-2014: Professional Services Manager, North America

I managed all the aspects of post-sale customer relationship and retention, as the main point of contact for the customer, being their internal champion and making sure every onboarded customer became an evangelist for Denodo's technology in later sales cycles with other prospective customers.

Managed the US software engineering team to analyze, design and implement customer projects.

Experience in dozens of projects of Enterprise Data Virtualization to fulfill the data delivery needs of the customers.

Also worked with our CEO and Sales VP for North America in reviewing commercial proposals to verify the licensing and professional services terms were realistic, achievable and appropriately priced and presented to customers.


## 2009-2011: Customer Support and Customer Training Manager, North America

I managed the customer support team to provide assistance in designing, developing and troubleshooting data virtualization solutions, helping strategic customers to go into production within the planned schedules.

Helped retain customers through timely resolution of all technical problems, analysis and delivery of new custom features.

Managed the training team to teach customers the use of the Denodo Platform, making possible for them to start using the purchased software right away.

Participated in the creation of the [training curriculum](http://www.denodo.com/en/services/education/courses/developers) and maintained it through several versions of the Denodo Platform which were taught to virtually all of Denodo's new customers.


## 2007-2009: Lead User Experience Engineer

Responsible for continuous analysis of software capabilities, gathering new customer requirements and creation of successful UI designs for the whole suite of the company's enterprise software, of high functional complexity.

I introduced changes that improved both customer win rate and customer satisfaction, taking into account customer needs, technical feasibility and planning, visual design and interaction. As an example, conceptualized, designed, presented and implemented the Denodo Platform Control Center, a new tool for managing the local installation of the Denodo Platform, which has been in production for over eight years and it's used by every customer of Denodo.

## 2005-2007: Software Engineer

I was in charge of creating from scratch (first commit) the client tools in the Denodo Platform that have been in production for over ten years and used by every customer to develop data virtualization solutions. The main tools are the main administration and development tool for the data virtualization server, and the web automation design tool for the web integration server. Both tools are highly interactive with a extremely deep feature set. As part of this development, I gained a very strong experience in both desktop and server side development.

___
