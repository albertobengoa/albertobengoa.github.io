
## [TTT](http://play-ttt.com)


I loved to play [Blockout](https://en.wikipedia.org/wiki/Blockout) (a 3D Tetris) when I was a kid - I missed it so I built a clone as a fun way of learning new technologies. In this case, [Clojurescript](https://github.com/clojure/clojurescript) and [reagent](https://github.com/reagent-project/reagent) + [re-frame](https://github.com/Day8/re-frame) (Clojurescript bindings for [Facebook's React](https://facebook.github.io/react/)). This game is a problem that is well defined, it is simple enough that can be programmed and/or ported in a short time, but it has enough complexity to be an interesting task that showcases strengths and weaknesses of each particular technology in the mix, so it is great for learning new languages and frameworks.

QA and playtesting were succsesful, with the side effect of making impossible for my mother to stop playing anymore.

### Status

[Live online](http://play-ttt.com).

A series of posts are also in the making, explaining how it was built from beginning to end (including parts such as the menu system or the pseudo-3D renderer), to work as a more complete tutorial for newcomers to these technologies than the usual "let's build a BMI calculator".

## [Newsogen](http://newsogen.com)

An online RSS reader that fills the void left when Google closed Google Reader. It has a clean and uncluttered interface, fast mouse and keyboard controls and works well in PC, tablet and mobile. The demise of Google Reader was a hard pill to swallow, but fortunately creating a replacement was both easy and very rewarding.

Some details about this implementation:

 - It was programmed in 100% Clojure and deployed in Heroku, with a PostgreSQL backend DB.

 - The parsing of the feeds is done manually (without assisting libraries).

 - The generated output is plain HTML with a bit of JavaScript logic that is used for marking each entry as read, which works great both in desktop, tablet and mobile.

### Status

[Live online](http://newsogen.com), with daily personal usage.


## [Usertron](http://usertron.com)

Usertron is an online authentication management system - it allows to add user authentication easily to any project through a simple REST API.

I am building Usertron as a side project that aims to simplify creating new side projects. One of the most common tasks that is needed when creating new projects is adding the necessary infrastructure for user accounts, including user authentication, password recovery, logging of authentication attempts, user management and secure storage of user credentials. These tasks are not trivial, so having them centralized in a separate service allows to implement them right once, then reuse them as needed; being a REST API it is language-agnostic so any project can integrate this authentication service.

### Status
Work in progress.

- The service is currently working.

    - Alpha status: SSL is not configured yet, several parts of the infrastructure need stronger testing.


- The documentation needs to be completed.

- The administration interface is very limited.

___
