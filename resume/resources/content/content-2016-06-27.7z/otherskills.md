
## Spoken Languages

Fluent in English, Spanish and Galician.

Beginner in Bulgarian.

## [Photography](http://albertobengoa.com/photosite)


Photography is one of my biggest passions, my creative outlet - it combines both artistic sensibility and technical skills, which makes it very rewarding and gives it enough depth to keep exploring after a long time. I have been photographing for more than ten years, shooting with a variety of equipment ranging from digital compacts to large format film cameras. Mainly focused in landscape and portraits. Check [my online gallery](http://albertobengoa.com/photosite) for some favorite landscapes gathered throughout the years.


##  Miscellaneous

I love music, both listening and playing (I played clarinet and sang in a choir for a long time, alas not recently), chess (an incredibly rich game that continually insists on teaching me how badly I play), hiking (the Bay Area has been extremely rewarding in this regard), biking and running (for a bit of exercise - running was a previous past time, recent knee problems have made me transition to biking) and cooking delicious dishes.

Other personal technical projects and interests:

  - I'm currently building a house automation suite based on arduino-compatible hardware, and creating the software to control all the remote sensors and actuators.

  - The Print Curator, a site for managing and sharing metadata about traditional darkroom printing. Defunct after a sharp decrease in film photography in the last 4 years.

  - Mouse gestures recognition in Java GUIs - thinking about resurrecting it in JavaScript!

  - 2D and 3D fractal generation, rendering and animation. 3D fractals can be quite mesmerizing.

  - Application event buses, which simplified building Java applications.

  - Time tracking software, to create reports of time spent on each individual task.

  - Identification of users based on typing patterns, using artificial neural networks.
