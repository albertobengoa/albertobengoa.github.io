- **A product and team manager who can code,**

- **with customer-facing experience in various capacities,**

- **interacting with internal engineers, third party partners, industry analysts and c-level executives,**

- **with knowledge of different areas of the data management business,**

- **a strong computer science background,**

- **ability for technical writing and teaching**

- **and passion for software that improves people's lives, both creating it and managing teams and processes that make it a reality.**


#### Skillset:

2+ years of product management in the highly technical, highly competitive field of data virtualization. Products currently managed include our public community site, the free version of the Denodo Platform for data virtualization, the Denodo Platform for AWS, and several enterprise ecosystem products that extend the core Denodo Platform. Other responsibilities include technical writing, customer outreach, technical partnerships management and customer training.

Experience conceptualizing, planning and executing multiple high-visibility, high-impact projects that span several departments; deep knowledge of data virtualization and data integration in enterprise environments, both at the architecture and implementation levels.

Past projects involved many customer company sizes - from sub-10 employees firms to global enterprises (such as IBM, Cisco, Intel, Caterpillar) and required the background and experience to understand everybody's point of view, from sales to engineers to executives; 4 years of experience managing technical teams for professional services for custom-tailored projects, in fields such as legacy systems migrations, web automation, Hadoop and data warehouse integration, B2B data integration, etc.

___
